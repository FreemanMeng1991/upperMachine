# coding:utf-8
import sys
from PyQt5.Qt import *
from PyQt5.QtWidgets import QApplication,QWidget,QGridLayout,QFileDialog
from framelesswindow import FramelessWindow
from ui_MainWindow import Ui_MainWindow
from messagebox import MessageBox
from titlebar import TitleBar
from Crypto.Cipher import AES
import base64



class Window(FramelessWindow):
    """ ！！！NOTE！！！：FramelessWindow类已经创建了标题栏实例TitleBar，Window类里不能再创建 
        否则会出现两个标题栏相互遮盖，导致异常运行。该问题通过在qss中将标题栏设为透明时意外发现
    """
    def __init__(self, parent=None):
        super().__init__(parent=parent)
        self.setMinimumHeight(500)  #窗体最小高度
        self.setMinimumWidth(600)   #窗体最小宽度
        self.initUI()
        self.setWindowTitle('任务栏窗口标题') #设置任务栏小窗标题

    def initUI(self): 
        self.init_vars()    #初始化所有变量            
        self.init_layout()  #设置界面布局    
        self.set_signal_slots() #设置信号与槽函数


    def init_layout(self):
        layout=QHBoxLayout() #创建QGridLayout的实例，并设置窗口的布局
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        #设置全局qss, 注意：qss文件中不能有中文
        with open(r'resource\qss\global_styles.qss', encoding='utf-8') as f: 
            self.setStyleSheet(f.read())
        layout.addWidget(self.ui.main_widget)
        layout.setContentsMargins(0,0,0,0) #无边缘，所有控件顶满显示
        self.setLayout(layout)
        self.titleBar.win_title.setText(" 智能张拉系统注册机")
        self.titleBar.raise_() #最后将标题栏置顶，使其不被其他控件遮盖而无法操作
        # self.titleBar.move(0,20) 标题栏默认在最顶端，取消注释可令其改变位置
        # self.ui.win_title.raise_()
        self.move(300, 150)  
        # self.ui.activation_code.setText("")


    def init_vars(self):
        self.key = 'kfvccaxjzxxumeng'

    def set_signal_slots(self):
        self.ui.generate_btn.clicked.connect(self.make_activation_code)
    
    def make_activation_code(self):
        usr_uuid  = self.ui.usr_uuid.text()
        expt_time = self.ui.expiration.text()
        if len(usr_uuid) != 8:
            reply = MessageBox.warning(None,"警告","识别码长度不正确", MessageBox.YES)
            return()
        if not len(expt_time):
            reply = MessageBox.warning(None,"警告","请指定授权时间长度", MessageBox.YES)
            return()
        self.ui.activation_code.setText(self.aesEncrypt(self.key, usr_uuid+expt_time)[:-2])



    def pad_data(self, s,BLOCK_SIZE=16):
        return(s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * chr(BLOCK_SIZE - len(s) % BLOCK_SIZE))

    def unpad_data(self, s,BLOCK_SIZE=16):
        return(s[:-ord(s[len(s) - 1:])])

    def aesEncrypt(self, key, data):
        '''
        AES的ECB模式加密方法
        :param key: 密钥
        :param data:被加密字符串（明文）
        :return:密文
        '''
        key = key.encode('utf8')
        # 字符串补位
        data = self.pad_data(data)
        cipher = AES.new(key, AES.MODE_ECB)
        # 加密后得到的是bytes类型的数据，使用Base64进行编码,返回byte字符串
        result = cipher.encrypt(data.encode())
        encodestrs = base64.b64encode(result)
        enctext = encodestrs.decode('utf8')
        print(enctext)
        return enctext

    def aesDecrypt(self, key, data):
        '''
        :param key: 密钥
        :param data: 加密后的数据（密文）
        :return:明文
        '''
        key = key.encode('utf8')
        data = base64.b64decode(data)
        cipher = AES.new(key, AES.MODE_ECB)

        # 去补位
        text_decrypted = unpad_data(cipher.decrypt(data))
        text_decrypted = text_decrypted.decode('utf8')
        print(text_decrypted)
        return text_decrypted

        
    # 防止ui_MainWindow.py运行时MainWindow对象没有相应的方法而报错
    def setTabShape(self,a):
        pass
    def setCentralWidget(self,a):
        pass
    def setStatusBar(self,a):
        pass


#供调试时使用，改完logic不必切换到main.py后再运行程序
if __name__ == "__main__":
    app = QApplication(sys.argv)
    demo = Window()
    demo.show()
    # demo.showMinimized()
    sys.exit(app.exec_())
