# coding:utf-8
import sys
from PyQt5.QtWidgets import QApplication
from logics import Window

if __name__ == "__main__":
    app = QApplication(sys.argv)
    demo = Window()
    demo.show()
    sys.exit(app.exec_())
