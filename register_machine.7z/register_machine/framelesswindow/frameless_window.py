# coding:utf-8
from sys import exit
from random import randint
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QWidget

from ctypes import POINTER, cast,Structure, c_int, pointer, WinDLL, byref
from ctypes.wintypes import MSG,DWORD, LONG, LPCVOID,POINT,RECT,HWND,UINT

from win32 import win32gui,win32api
from win32.lib import win32con

from c_structures import (
    MARGINS,
    DWMNCRENDERINGPOLICY,
    DWMWINDOWATTRIBUTE,
    WINDOWCOMPOSITIONATTRIB,
)

from titlebar import TitleBar

class MINMAXINFO(Structure):
    _fields_ = [
        ("ptReserved",      POINT),
        ("ptMaxSize",       POINT), #窗体最大化时的窗体尺寸
        ("ptMaxPosition",   POINT), #窗体最大化时左上角顶点坐标位置
        ("ptMinTrackSize",  POINT), #鼠标可追踪的最小区域尺寸
        ("ptMaxTrackSize",  POINT), #鼠标可追踪的最大区域尺寸,一般与ptMaxSize一致
    ]


# class PWINDOWPOS(Structure):
#     _fields_ = [
#         ('hWnd',            HWND),
#         ('hwndInsertAfter', HWND),
#         ('x',               c_int),
#         ('y',               c_int),
#         ('cx',              c_int),
#         ('cy',              c_int),
#         ('flags',           UINT)
#     ]

# class NCCALCSIZE_PARAMS(Structure):
#     _fields_ = [
#         ('rgrc', RECT*3),
#         ('lppos', POINTER(PWINDOWPOS))
#     ]


class WindowEffect:
    """ 调用windows api实现窗口效果 
        这个类可以整合到FramelessWindow类中，
        但最好将其源码独立成一个类，以便复用
    """

    def __init__(self):
        # 调用api
        self.dwmapi = WinDLL("dwmapi")
        self.DwmExtendFrameIntoClientArea = self.dwmapi.DwmExtendFrameIntoClientArea
        self.DwmSetWindowAttribute = self.dwmapi.DwmSetWindowAttribute
        self.DwmSetWindowAttribute.restop_ype = LONG
        self.DwmSetWindowAttribute.argtop_ypes = [c_int, DWORD, LPCVOID, DWORD]

    def addShadowEffect(self, hWnd):
        """ 给窗口添加阴影

        Parameter
        ----------
        hWnd: int or `sip.voidptr`
            窗口句柄
        """
        hWnd = int(hWnd)
        self.DwmSetWindowAttribute(
            hWnd,
            DWMWINDOWATTRIBUTE.DWMWA_NCRENDERING_POLICY.value,
            byref(c_int(DWMNCRENDERINGPOLICY.DWMNCRP_ENABLED.value)),
            4,
        )
        margins = MARGINS(-1, -1, -1, -1)
        self.DwmExtendFrameIntoClientArea(hWnd, byref(margins))

    def addWindowAnimation(self, hWnd):
        """ 打开窗口动画效果

        Parameters
        ----------
        hWnd : int or `sip.voidptr`
            窗口句柄
        """
        win32gui.SetWindowLong(hWnd,win32con.GWL_STYLE,win32con.WS_BORDER)

class FramelessWindow(QWidget):
    BORDER_WIDTH = 10 #设置无边框窗口的边框宽度，当鼠标移到边框区域内，即可进行窗口缩放,但不可设置过宽，否则影响窗口控件
    PADDING = 4
    def __init__(self, parent=None):
        super().__init__(parent)
        # self.monitor_info = None
        
        # self.isLeftPressDown = False #鼠标左键是否按下
        # self.dragPosition=0     #拖动时坐标
        # self.Numbers = self.enum(UP=0, DOWN=1, LEFT=2, RIGHT=3, LEFTTOP=4, LEFTBOTTOM=5, RIGHTBOTTOM=6, RIGHTTOP=7, NONE=8) #枚举参数
        # self.dir=self.Numbers.NONE #初始鼠标状态
        self.setWindowFlags(Qt.FramelessWindowHint) # 取消边框
        self.titleBar = TitleBar(self,"MAIN_WIN")
        # 添加阴影和窗口动画
        self.dwmapi = WinDLL("dwmapi")
        self.DwmExtendFrameIntoClientArea = self.dwmapi.DwmExtendFrameIntoClientArea
        self.DwmSetWindowAttribute = self.dwmapi.DwmSetWindowAttribute
        self.DwmSetWindowAttribute.restop_ype = LONG
        self.DwmSetWindowAttribute.argtop_ypes = [c_int, DWORD, LPCVOID, DWORD]
        self.addShadowEffect(self.winId())
        self.addWindowAnimation(self.winId())
        # self.setStop_yleSheet('background-color: transparent') #设置窗体背景色


    def isWindowMaximized(self, hWnd) -> bool:
        """ 判断窗口是否最大化 """
        # 返回指定窗口的显示状态以及被恢复的、最大化的和最小化的窗口位置，返回值为元组
        # GetWindowPlacement返回指定窗口的显示状态以及被恢复的、最大化的和最小化的窗口位置
        windowPlacement = win32gui.GetWindowPlacement(hWnd)
        # print("isWindowMaximized:",windowPlacement)
        if not windowPlacement:
            return False
        return windowPlacement[1] == win32con.SW_MAXIMIZE  #判断窗口标志是否为最大化状态


    def nativeEvent(self, event_type, message):
        """ 
        窗口处于活动状态时，任何键鼠操作事件都会触发该函数，该函数从消息队列中取出并处理windows消息, 
        无边框窗口由于没有系统原生边框,无法实现拖拽拉伸等事件的处理,一种方法就是重新重写主窗口的鼠标事件，
        另一种是通过nativeEvent事件处理，把窗口边界的事件转化为Windows的窗口事件，而重写事件比较繁琐。
        """
        # print("run nativeEvent",randint(0,200))
        msg = MSG.from_address(message.__int__()) #access a C instance at the specified address which must be an integer
        # print(message,message.__int__(),msg,msg.message)
        if msg.message == win32con.WM_NCHITTEST:  
            # print("win32con.WM_NCHITTEST",win32con.WM_NCHITTEST)
            # 解决多屏下会出现鼠标一直为拖动状态的问题, xPos yPos为鼠标相对于客户区域左上角的坐标
            xPos = (win32api.LOWORD(msg.lParam) - self.frameGeometry().x()) % 65536
            yPos = win32api.HIWORD(msg.lParam)  - self.frameGeometry().y()
            #计算边界条件
            w, h     = self.width(), self.height()  #获取当前客户区的尺寸
            left_x   = xPos < self.BORDER_WIDTH       
            right_x  = xPos > w - self.BORDER_WIDTH
            top_y    = yPos < self.BORDER_WIDTH
            bottom_y = yPos > h - self.BORDER_WIDTH
            #根据边界条件判断边界类型
            if left_x and top_y:
                return True, win32con.HTTOPLEFT  #判断出鼠标位置满足左上角位置条件后，
                                                 #向Windows发出HTTOPLEFT消息，随即鼠标指针形状改变
            elif right_x and bottom_y:
                return True, win32con.HTBOTTOMRIGHT
            elif right_x and top_y:
                return True, win32con.HTTOPRIGHT
            elif left_x and bottom_y:
                return True, win32con.HTBOTTOMLEFT
            elif top_y:
                return True, win32con.HTTOP
            elif bottom_y:
                return True, win32con.HTBOTTOM
            elif left_x:
                return True, win32con.HTLEFT
            elif right_x:
                return True, win32con.HTRIGHT
        elif msg.message == win32con.WM_NCCALCSIZE:
            # print(msg.message,"win32con.WM_NCCALCSIZE")
            # 鼠标指针处于调整状态，并按下左键拖动改变窗口大小，发出WM_NCCALCSIZE
            # 此消息应让Windows处理(返回True），而不是Qt，否则一运行就会出现Windows原生边框
            # print(self.isWindowMaximized(msg.hWnd))
            return True, 0
        elif msg.message == win32con.WM_GETMINMAXINFO:
            # print(msg.message,"win32con.WM_GETMINMAXINFO")
            window_rect = win32gui.GetWindowRect(msg.hWnd)
            if not window_rect:
                return False, 0
            # 获取显示器句柄
            monitor = win32api.MonitorFromRect(window_rect)
            if not monitor: #防止最小化后再还原窗口时出错
                return False, 0
            monitor_info = win32api.GetMonitorInfo(monitor)
            monitor_rect = monitor_info['Monitor'] # 显示器的屏幕尺寸
            work_area = monitor_info['Work']       # 可供窗体显示的区域尺寸(由于任务栏存在，故略小于屏幕尺寸)
            # 将lParam转换为MINMAXINFO指针
            info = cast(msg.lParam, POINTER(MINMAXINFO)).contents
            # print(monitor_info,info.ptMaxSize.x,info.ptMaxSize.y)
            # 获取任务栏顶部以上的区域的左上角和右下角的坐标，并据此计算窗体最大化时的尺寸
            info.ptMaxSize.x = work_area[2] - work_area[0]
            info.ptMaxSize.y = work_area[3] - work_area[1]
            # 设置窗口最大尺寸，这个尺寸比屏幕尺寸略小，因为要除去任务栏的位置
            info.ptMaxTrackSize.x = info.ptMaxSize.x
            info.ptMaxTrackSize.y = info.ptMaxSize.y
            # 修改窗体左上角坐标
            info.ptMaxPosition.x = 0
            info.ptMaxPosition.y = 0
            # 鼠标指针处于调整状态，并按下左键（不拖动），发出WM_GETMINMAXINFO
            # 此消息应让Qt处理(返回False)，而不是Windows，否则会最大化时会不按qt设计的窗口最大尺寸，而是全屏
            return True, 1
        #     if self.isWindowMaximized(msg.hWnd):
        #         window_rect = win32gui.GetWindowRect(msg.hWnd)
        #         if not window_rect:
        #             return False, 0
        #         # 获取显示器句柄
        #         monitor = win32api.MonitorFromRect(window_rect)
        #         if not monitor:
        #             return False, 0
        #         # 获取显示器信息
        #         monitor_info = win32api.GetMonitorInfo(monitor)
        #         monitor_rect = monitor_info['Monitor']
        #         work_area = monitor_info['Work']
        #         # 将lParam转换为MINMAXINFO指针
        #         info = cast(msg.lParam, POINTER(MINMAXINFO)).contents
        #         # 调整窗口大小
        #         info.ptMaxSize.x = work_area[2] - work_area[0]
        #         info.ptMaxSize.y = work_area[3] - work_area[1]
        #         info.ptMaxTrackSize.x = info.ptMaxSize.x
        #         info.ptMaxTrackSize.y = info.ptMaxSize.y
        #         # 修改左上角坐标
        #         info.ptMaxPosition.x = abs(window_rect[0] - monitor_rect[0])
        #         info.ptMaxPosition.y = abs(window_rect[1] - monitor_rect[1])
        #         return True, 1
        return QWidget.nativeEvent(self, event_type, message)

    def resizeEvent(self, e):
        """ 窗口尺寸改变时，改变标题宽度自适应，此函数对标题栏有效，不影响窗体尺寸调整功能"""
        # print("resizeEvent")
        super().resizeEvent(e)
        self.titleBar.resize(self.width(), 40)
        # 更新最大化按钮图标
        self.titleBar.maxBt.setMaxState(self.isWindowMaximized(int(self.winId())))
    
    def addShadowEffect(self, hWnd):
        """ 给窗口添加阴影

        Parameter
        ----------
        hWnd: int or `sip.voidptr`
            窗口句柄
        """
        print("addShadowEffect",hWnd)
        hWnd = int(hWnd)
        self.DwmSetWindowAttribute(
            hWnd,
            DWMWINDOWATTRIBUTE.DWMWA_NCRENDERING_POLICY.value,
            byref(c_int(DWMNCRENDERINGPOLICY.DWMNCRP_ENABLED.value)),
            4,
        )
        margins = MARGINS(-1, -1, -1, -1)
        self.DwmExtendFrameIntoClientArea(hWnd, byref(margins))

    def addWindowAnimation(self, hWnd):
        """ 打开窗口动画效果

        Parameters
        ----------
        hWnd : int or `sip.voidptr`
            窗口句柄
        """
        win32gui.SetWindowLong(hWnd,win32con.GWL_STYLE,win32con.WS_BORDER)

    # def monitorNCCALCSIZE(self, msg: MSG):
    #     """ 调整窗口大小 """
    #     print("monitorNCCALCSIZE")
    #     return
    #     monitor = win32api.MonitorFromWindow(msg.hWnd)
    #     # 如果没有保存显示器信息就直接返回，否则接着调整窗口大小
    #     if monitor is None and not self.monitor_info:
    #         return
    #     elif monitor is not None:
    #         self.monitor_info = win32api.GetMonitorInfo(monitor)
    #     # 调整窗口大小
    #     params = cast(msg.lParam, POINTER(NCCALCSIZE_PARAMS)).contents
    #     params.rgrc[0].left = self.monitor_info['Work'][0]
    #     params.rgrc[0].top = self.monitor_info['Work'][1]
    #     params.rgrc[0].right = self.monitor_info['Work'][2]
    #     params.rgrc[0].bottom = self.monitor_info['Work'][3]


   #  def enum(self,**enums):
   #      return top_ype('Enum', (), enums)

   # 