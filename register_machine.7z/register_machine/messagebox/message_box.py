from PyQt5.QtWidgets import QDialog, QApplication, QPushButton, QSizePolicy
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QPixmap, QIcon
from ui_MessageBox import Ui_Dialog
from titlebar import TitleBar
import sys

class MessageBox(QDialog):
    """ 自定义MessageBox，继承自QDialog     
    其中有3个static method可用: information, warning, error，使用方法与QMessageBox基本一致
    Args:   
        parent: 父窗口
        title: MessageBox窗口标题 Window Title
        text: 消息文本
        btype: 按钮，有五种类型按钮：YES, NO, CANCLE, CLOSE, OK
        default: 默认按钮，默认值为YES
    """
    # 仅支持这几个按键
    YES    = 0x01
    NO     = 0x02
    CANCEL = 0x04
    CLOSE  = 0x08
    OK     = 0x10
    # 返回值
    retValue = 0

    def __init__(self, parent, title: str, text: str, btype=YES, default=YES):
        super().__init__(parent)
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        self.ui.lb_text.setText(text)  #设定弹窗标题
        self.setWindowFlags(Qt.FramelessWindowHint | 
                            Qt.WindowSystemMenuHint |
                            Qt.WindowMinimizeButtonHint | 
                            Qt.WindowMaximizeButtonHint |
                            Qt.SubWindow) #隐藏弹窗边框和标题栏，且弹窗不在任务栏上显示
        self.setWindowModality(Qt.ApplicationModal) #设弹窗为模态窗口，即弹窗口关闭之前，其父窗口不可能成为活动窗口
        self.setAttribute(Qt.WA_QuitOnClose, True)
        self.titleBar = TitleBar(self,"MSG_BOX") #为弹窗创建标题栏
        self.btnList = {}
        self.create_button(btype)  #添加弹窗按钮
        self.set_default_btn(btype, default) #设定默认按钮
        with open(r'resource\qss\msg_box.qss', encoding='utf-8') as f:
            self.setStyleSheet(f.read())
        print(self.btnList[default])
        self.btnList[default].setCheckable(True)
        self.btnList[default].setChecked(True)
        self.btnList[default].setDefault(True)


    def create_button(self, btype):
        # 如果按钮是yes
        if btype & MessageBox.YES == MessageBox.YES:
            self.yesbtn = QPushButton(self)
            self.yesbtn.setObjectName("YES_BTN")
            self.set_button(self.yesbtn, u'是')
            self.btnList[MessageBox.YES] = self.yesbtn
            self.yesbtn.clicked.connect(self.btn_yes)

        # 如果按钮是no
        if btype & MessageBox.NO == MessageBox.NO:
            self.nobtn = QPushButton(self)
            self.set_button(self.nobtn, u'否')
            self.nobtn.setObjectName("NO_BTN")
            self.btnList[MessageBox.NO] = self.nobtn
            self.nobtn.clicked.connect(self.btn_no)
        # 如果按钮是cancel
        if btype & MessageBox.CANCEL == MessageBox.CANCEL:
            self.cancelbtn = QPushButton(self)
            self.set_button(self.cancelbtn, u'取消')
            self.cancelbtn.setObjectName("CANCEL_BTN")
            self.btnList[MessageBox.CANCEL] = self.cancelbtn
            self.cancelbtn.clicked.connect(self.btn_cancel)
        # 如果按钮是close
        if btype & MessageBox.CLOSE == MessageBox.CLOSE:
            self.closebtn = QPushButton(self)
            self.set_button(self.closebtn, u'关闭')
            self.closebtn.setObjectName("CLOSE_BTN")
            self.btnList[MessageBox.CLOSE] = self.closebtn
            self.closebtn.clicked.connect(self.btn_close)
        # 如果按钮是ok
        if btype & MessageBox.OK == MessageBox.OK:
            self.okbtn = QPushButton(self)
            self.set_button(self.okbtn, u'确定')
            self.okbtn.setObjectName("OK_BTN")
            self.btnList[MessageBox.OK] = self.okbtn
            self.okbtn.clicked.connect(self.btn_ok)

    def set_default_btn(self, btype, default):
        # default键必须是一个独立的按键
        if default not in {MessageBox.YES, MessageBox.NO, MessageBox.CANCEL, MessageBox.OK, MessageBox.CLOSE}:
            print("pass")
            return
        if default & btype != 0:
            # print("0",self.btnList[default],dir(self.btnList[default]))
            self.btnList[default].setChecked(True)
            self.btnList[default].setDefault(True)
            self.btnList[default].setCheckable(True)
            

    def set_button(self, btn:QPushButton, text:str):
        # 设置按钮的尺寸和文本，并将按钮添加到窗口的某个布局中(这里是水平布局)
        btn.setText(text)
        btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        btn.setFixedSize(QSize(95, 35))
        self.ui.horizontalLayout_2.addWidget(btn) #只有创建了Layout对象，才能使用addWidget


    #不同类型的弹窗按钮绑定不同的槽函数
    def btn_yes(self):
        MessageBox.retValue = MessageBox.YES
        self.close()
        
    def btn_no(self):
        MessageBox.retValue = MessageBox.NO
        self.close()
        
    def btn_cancel(self):
        MessageBox.retValue = MessageBox.CANCEL
        self.close()
        
    def btn_close(self):
        MessageBox.retValue = MessageBox.CLOSE
        self.close()
        
    def btn_ok(self):
        MessageBox.retValue = MessageBox.OK
        self.close()

    def ret_val(self):
        return MessageBox.retValue

    # 使用时调用的静态方法,创建不同类型的弹窗,但实际上本质一样,只是外观略有不同
    @staticmethod
    def information(parent, title, text, btype=YES, default=YES):
        box = MessageBox(parent, title, text, btype, default)
        box.ui.box_title.setText("通知")
        box.ui.pbt_icon.setPixmap(QPixmap("./resource/images/popup_box/info_blue.png"))
        box.exec()
        return box.ret_val()

    @staticmethod
    def warning(parent, title, text, btype=YES, default=YES):
        box = MessageBox(parent, title, text, btype, default)
        box.ui.box_title.setText("警告")
        box.ui.pbt_icon.setPixmap(QPixmap("./resource/images/popup_box/warning_red.png"))
        box.exec()
        return box.ret_val()

    @staticmethod
    def error(parent, title, text, btype=YES, default=YES):
        box = MessageBox(parent, title, text, btype, default)
        box.ui.box_title.setText("错误")
        box.ui.pbt_icon.setPixmap(QPixmap("./resource/images/popup_box/error_red.png"))
        box.exec()
        return box.ret_val()
        box.exec()
        return box.ret_val()
