# coding:utf-8
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QIcon, QResizeEvent, QPixmap
from PyQt5.QtWidgets import QLabel, QWidget, QToolButton
from win32.lib import win32con
from win32.win32api import SendMessage
from win32.win32gui import ReleaseCapture
from .title_bar_buttons import MaximizeButton, MinCloseButton


class TitleBar(QWidget):
    """ 定义标题栏，根据不同的窗口类型，创建出不同样式的标题栏"""
    def __init__(self, parent,type_str):
        self.is_msg_box = False
        if type_str == "MSG_BOX":
            self.is_msg_box = True
            super().__init__(parent)
            self.resize(480, 100) #自定义弹窗宽度值与ui_MessageBox.py中的宽度保持一致，这样关闭按钮的位置才正确
            # 实例化弹框小部件
            self.__createMsgboxButtons()
            # 初始化弹框界面
            self.__initMsgboxWidget()
            self.__adjustMsgboxButtonPos()
            # self.setLayout(self.layout)
        if type_str == "MAIN_WIN":
            super().__init__(parent)
            self.resize(350, 100) #宽度值与自定义弹窗的宽度保持一致，这样关闭按钮的位置才正确
            # 实例化小部件(MainWindow)
            self.__createButtons()
            # 初始化界面
            self.__initWidget()
            self.__adjustButtonPos()



    def __createButtons(self):
        """ 创建主窗口的窗体控制按钮 """
        self.minBt = MinCloseButton(
            {'normal': r'resource\images\title_bar\最小化按钮_normal_57_40.png',
             'hover': r'resource\images\title_bar\最小化按钮_hover_57_40.png',
             'pressed': r'resource\images\title_bar\最小化按钮_pressed_57_40.png'}, (57, 40), self)
        self.closeBt = MinCloseButton(
            {'normal': r'resource\images\title_bar\关闭按钮_normal_57_40.png',
             'hover': r'resource\images\title_bar\关闭按钮_hover_57_40.png',
             'pressed': r'resource\images\title_bar\关闭按钮_pressed_57_40.png'}, (57, 40), self)
        self.maxBt = MaximizeButton(self)
        self.win_icon = QToolButton(self)
        self.win_icon.setMinimumSize(QSize(20, 20))
        self.win_icon.setObjectName("win_icon")
        self.win_title = QToolButton(self)
        self.win_title.setMinimumSize(QSize(120, 40))
        

    def __createMsgboxButtons(self):
        """ 创建弹窗的窗体控件按钮 """
        self.closeBt = MinCloseButton(
            {'normal': r'resource\images\title_bar\关闭按钮_msgbox_normal_57_40.png',
             'hover': r'resource\images\title_bar\关闭按钮_hover_57_40.png',
             'pressed': r'resource\images\title_bar\关闭按钮_pressed_57_40.png'}, (57, 40), self)
        # self.title_label = QPushButton()
        


    def __initWidget(self):
        """ 初始化小部件 """
        self.setFixedHeight(40) #设定标题栏高度
        self.setAttribute(Qt.WA_StyledBackground) #qss支持，防止Qt中继承QWidget之后，样式表不起作用
        self.loadQSS()   #设定样式
        # 将按钮的点击信号连接到槽函数
        self.minBt.clicked.connect(self.window().showMinimized)
        self.maxBt.clicked.connect(self.setMaximizedWindow)
        self.closeBt.clicked.connect(self.window().close)
        self.minBt.setFocusPolicy(Qt.NoFocus)
        self.maxBt.setFocusPolicy(Qt.NoFocus)
        self.closeBt.setFocusPolicy(Qt.NoFocus)
        # self.minBt.setMouseTracking(True)  #鼠标在控件上移动时可追踪位置，非必要
        # self.maxBt.setMouseTracking(True)  #鼠标在控件上移动时可追踪位置，非必要
        # self.closeBt.setMouseTracking(True)#鼠标在控件上移动时可追踪位置，非必要

    def __initMsgboxWidget(self):
        """ 初始化小部件 """
        self.setFixedHeight(40) #40
        self.setAttribute(Qt.WA_StyledBackground) #qss支持，防止Qt中继承QWidget之后，样式表不起作用
        self.loadQSS()
        # 将按钮的点击信号连接到槽函数
        self.closeBt.clicked.connect(self.window().close)
        self.closeBt.setFocusPolicy(Qt.NoFocus)
 


    def __adjustButtonPos(self):
        """ 将最小、最大、关闭三个按键放到标题栏上，并在窗口大小变化时保持其相对位置不变 """
        self.closeBt.move(self.width() - 57, 0)
        self.maxBt.move(-self.width() - 2* 57, 0) #将最大化按钮隐藏（移出窗口）
        self.minBt.move(self.width() - 2* 57, 0)
        self.win_icon.move(5,0)
        self.win_title.move(28,0)

    def __adjustMsgboxButtonPos(self):
        """ 将最小、最大、关闭三个按键放到标题栏上，并在窗口大小变化时保持其相对位置不变 """
        self.closeBt.move(self.width() - 57, 0)
        # self.title_label.move(self.width() - 2*57,0)


    def resizeEvent(self, e: QResizeEvent):
        """ 尺寸改变时移动按钮 """
        if self.is_msg_box:
            pass  #弹框不能够改变大小，故不可resize
            # self.__adjustMsgboxButtonPos()
        else:
            self.__adjustButtonPos()

    def mouseDoubleClickEvent(self, event):
        """ 双击最大化窗口 """
        self.setMaximizedWindow()


    def mousePressEvent(self, event):
        """ 实现点击标题栏移动窗口 """
        # 判断鼠标点击位置是否允许拖动
        if self.testDragArea(event.pos()):
            ReleaseCapture() #左键点击住标题栏不放并拖动鼠标时，会调用SetCapture函数
                             #必须执行ReleaseCapture函数，才能正常处理鼠标事件，否则拖拽窗口时会无法移动
            SendMessage(self.window().winId(), 
                        win32con.WM_SYSCOMMAND,
                        win32con.SC_MOVE + win32con.HTCAPTION, 
                        0) #向窗口发送WM_SYSCOMMAND信息，通常从菜单中选择执行一条命令或点击窗体控件时产生该信息
                           #附加描述信息HTCAPTION：光标位于标题栏中；SC_MOVE：移动窗口
            # print("mousePressEvent")
            event.ignore()

    def setMaximizedWindow(self):
        """ 复原窗口并更换最大化按钮的图标 """
        if self.window().isMaximized():
            self.window().showNormal()
            # 更新标志位用于更换图标
            self.maxBt.setMaxState(False)
        else:
            self.window().showMaximized()
            self.maxBt.setMaxState(True)

    def testDragArea(self, pos) -> bool:
        """鼠标左键单击标题栏拖动窗口时，检查此时光标在标题栏上相对于当前窗口的水平位置，并确认该位置是否允许拖动操作。
           不同的窗口类型，由于窗体控制按钮的数量不同，其支持拖动的区域范围也不同，但总的来说，左起第一个窗体控制按钮的左边界
           即为可拖动区域的右边界，而可拖动区域的左边界与窗体左边界重合。"""
        x = pos.x()
        # 如果最小化按钮看不见也意味着最大化按钮看不见
        if self.is_msg_box:
            right = self.width() - 57  
        else:
            right = self.width() - 57 * 3 if self.minBt.isVisible() else self.width() - 57
        return (0 < x < right) #支持拖动返回True


    def loadQSS(self):
        """ 设置层叠样式 """
        if self.is_msg_box:
            # print("set box qss")
            with open(r'resource\qss\title_bar_msgbx.qss', encoding='utf-8') as f:
                self.setStyleSheet(f.read())
        else:
            with open(r'resource\qss\title_bar_mainwd.qss', encoding='utf-8') as f:
                self.setStyleSheet(f.read())
