# coding:utf-8
import sys
from uuid import uuid4
from random import randint
from PyQt5.Qt import QMainWindow
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QApplication
from UI_MainWindow import Ui_MainWindow
from PyQt5.QtWidgets  import QMessageBox
from PyQt5.QtCore import Qt

################################## 授权原理 ##########################################
# 请求码共12位，分3组，每组4位。 第1组为防伪信息，后2组为位置信息
# 1. 先基于char_set随机生成前4位防伪码。(char_set定义见代码)
# 2. 而后随机生成后8位位置码，每个位置码在字符集char_set中的下标值对12求余
#    以确保结果在[0-11]之间，并且这些余数(共8个，代表8个位置)值唯一，因此需要多次尝试。

# 授权码共12位。第1部分8位，是申请码前4位的变换，第2部分4位，包含授权时长，所有位置随机。
# 3. 请求码前4位在char_set中的下标值[u1,u2,u3,u4]，与请求码中间4位在char_set中
#    的下标值[p1,p2,p3,p4]进行异或得到:[u1^p1,u2^p2,u3^p3,u4^p4]
#    生成4组(每组2位)16进制表示的结果.
# 4. 将上述异或结果(8位16进制字符)按照步骤2中生成的8个位置放入12位授权码中的对应位置。
# 5. 授权码余下的4位中(具体位置随机而定)，第1位随机生成1个16进制数(X)，后三位是授权时长
#    T1,T2,T3 分别与 X 异或操作后的16进制结果。T1,T2,T3 是授权时长(0-4095)的16进制表示
#####################################################################################
 

class Window(QMainWindow):
    def __init__(self, parent=None):
        super(QMainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.init_vars()
        self.set_signal_slots()
   
       
    def init_vars(self):
        self.char_set = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']

    def set_signal_slots(self):
        self.ui.generate_key.clicked.connect(self.generate_key)
        self.ui.generate_request_code.clicked.connect(self.generate_request_code)
        self.ui.test_activation.clicked.connect(self.test_activation)

    def generate_key(self):
        request_code = self.ui.request_code.text().strip() # 授权码
        if (len(request_code)!=14):
            reply = QMessageBox.warning(self,"警告","请求码长度错误！", QMessageBox.Yes)
            return
        try:
            timespan = int(self.ui.time_span.text().strip())
        except:
            reply = QMessageBox.warning(self,"警告","授权时长设定错误(0-4095)！", QMessageBox.Yes)
            return
        valid_pos     = []  # 4位时长信息在12位授权码中的可用位置
        reg_code      = ['?','?','?','?','?','?','?','?','?','?','?','?'] # 存储12位授权码
        pos_char_idx  = [] # 12位请求码中后8位字符在字符集char_set中的下标位置
        insert_at= []      # 请求码前4位，与请求码中间4位，一一对应异或操作后，生成4组(每组2位)16进制表示的结果，
                           # insert_at 用于说明这8位异或结果放到授权码中的那些地方
        xor_str  = []  # 请求码前4位，与请求码中间4位，一一对应异或操作后，生成4组(每组2位)16进制表示的结果，
                       # xor_str用于存储这4组结果。 注意：每组结果都以字符形式保存，且去除0x开头
        pos_char = [request_code[5],request_code[6],request_code[7],request_code[8],request_code[10],request_code[11],request_code[12],request_code[13]]
                   # pos_char 用于保存请求码的后两组(每组4位)内容
        uid      = list(request_code[:4])
        uid_idx  = [self.char_set.index(uid[0]),self.char_set.index(uid[1]),self.char_set.index(uid[2]),self.char_set.index(uid[3])]
                   # 请求码前4位在字符集char_set中的下标位置

        for i in range(0,8): # 确定pos_char_idx内容
            pos_char_idx.append(self.char_set.index(pos_char[i]))
            insert_at.append(pos_char_idx[i]%12) #对12取余是因为授权码12位，下标范围为0-11

        for i in range(0,12): # 确定valid_pos内容
            if not (i in insert_at):
                valid_pos.append(i)

        # print("Uid: ",uid, "select from", uid_idx)
        # print("Pos String: ",pos_char, "select from",pos_char_idx)
        # print("Insert at: ", insert_at)
        
        #请求码前4位，与请求码中间4位，一一对应异或操作后，生成4组(每组2位)16进制表示的结果，
        for u_idx, p_idx in zip(uid_idx, pos_char_idx): 
            xor_str.append(str(hex(u_idx^p_idx)[2:]).upper().zfill(2))
            # print(u_idx,p_idx,str(hex(u_idx^p_idx)[2:]).upper().zfill(2))
            
        for i in range(0,8): #异或结果按位(共8位)放入授权码
            reg_code[insert_at[i]] = xor_str[i//2][i%2]
  
        # 授权码余下的4位中，第1位随机生成1个16进制数(X)，后三位是授权时长的16进表示(T1,T2,T2)
        # 将 T1,T2,T2 分别与 X 异或操作，生成3个新的16进制数，最后将这4位信息放入授权码的指定
        # 位置，指定位置存储在valid_pos中。
        X  = randint(0,15)
        T1 = timespan//256
        T2 = (timespan - T1*256)//16
        T3 = timespan - 256*T1 - 16*T2
        reg_code[valid_pos[0]] = str(hex(X)).upper()[-1]
        reg_code[valid_pos[1]] = str(hex(T1^X)).upper()[-1]
        reg_code[valid_pos[2]] = str(hex(T2^X)).upper()[-1]
        reg_code[valid_pos[3]] = str(hex(T3^X)).upper()[-1]

        KEY_str = "-".join(["".join(reg_code[:4]),"".join(reg_code[4:8]),"".join(reg_code[8:])])

        # print("Valid Pos",valid_pos)
        # print(reg_code)
        # print("".join(reg_code[8:]))
        # print("Registration Code: ",KEY_str)
        self.ui.KEY_str.setAlignment(Qt.AlignCenter)
        self.ui.KEY_str.setText(KEY_str)

    def generate_request_code(self):
        cnt = 0
        request_code = []
        valid_pos    = []
        pos_char     = [] 
        pos_char_idx = [0,0,0,0,0,0,0,0]
        insert_at    = ["X","X","X","X","X","X","X","X"]
        uid          = [self.char_set[randint(0,35)],self.char_set[randint(0,35)],self.char_set[randint(0,35)],self.char_set[randint(0,35)]]
       

        while(cnt<8):
            index = randint(0,35)
            if (index%12) not in insert_at:
                pos_char_idx[cnt] = index
                insert_at[cnt] = index%12
                cnt = cnt + 1

        for i in range(0,12):
            if not (i in insert_at):
                valid_pos.append(i)

        for i in pos_char_idx:
            pos_char.append(self.char_set[i])
        # pos_char = [char_set[pos_char_idx[0]],char_set[pos_char_idx[1]],char_set[pos_char_idx[2]],char_set[pos_char_idx[3]]]
        request_code = "-".join(["".join(uid),"".join(pos_char[:4]),"".join(pos_char[4:])])
        # print("############### Request Code Generate ################")
        # print("Uid: ",uid)
        # print("Select from: ", pos_char_idx)
        # print("Pos String: ",pos_char)
        # print("Insert at:",insert_at)
        # print("Request_code: ",request_code) 
        self.ui.request_code.setText(request_code)

    def test_activation(self):
        KEY_str = self.ui.KEY_str.text().strip()
        request_code = self.ui.request_code.text().strip()
        if (len(request_code)!=14):
            reply = QMessageBox.warning(self,"警告","请求码长度错误！", QMessageBox.Yes)
            return
        if (len(KEY_str)!=14):
            reply = QMessageBox.warning(self,"警告","激活码长度错误，首先请生成激活码！", QMessageBox.Yes)
            return
        valid_pos = []
        uid =  [request_code[0],request_code[1],request_code[2],request_code[3]]
        pos_char = [request_code[5],request_code[6],request_code[7],request_code[8],request_code[10],request_code[11],request_code[12],request_code[13]]
        pos_char_idx = [self.char_set.index(request_code[5]),self.char_set.index(request_code[6]), 
                        self.char_set.index(request_code[7]), self.char_set.index(request_code[8]), 
                        self.char_set.index(request_code[10]), self.char_set.index(request_code[11]), 
                        self.char_set.index(request_code[12]), self.char_set.index(request_code[13]),  
                       ]
        insert_at = [pos_char_idx[0]%12,pos_char_idx[1]%12,pos_char_idx[2]%12,pos_char_idx[3]%12,
                     pos_char_idx[4]%12,pos_char_idx[5]%12,pos_char_idx[6]%12,pos_char_idx[7]%12
                    ]

        for i in range(0,12):
            if not (i in insert_at):
                valid_pos.append(i)
        print("Extract at: ",insert_at)

        segments = KEY_str.split("-")
        sliced_k = []
        for s in segments:
            sliced_k.append(s[0])
            sliced_k.append(s[1])
            sliced_k.append(s[2])
            sliced_k.append(s[3])
        print(sliced_k)
        xor_u0 = eval("".join(['0x',sliced_k[insert_at[0]], sliced_k[insert_at[1]] ]))
        xor_u1 = eval("".join(['0x',sliced_k[insert_at[2]], sliced_k[insert_at[3]] ]))
        xor_u2 = eval("".join(['0x',sliced_k[insert_at[4]], sliced_k[insert_at[5]] ]))
        xor_u3 = eval("".join(['0x',sliced_k[insert_at[6]], sliced_k[insert_at[7]] ]))
        print(xor_u0,xor_u1,xor_u2,xor_u3)
        try:
            uid_chk= [self.char_set[xor_u0^pos_char_idx[0]],self.char_set[xor_u1^pos_char_idx[1]],
                      self.char_set[xor_u2^pos_char_idx[2]],self.char_set[xor_u3^pos_char_idx[3]]]
        except IndexError as e:
            reply = QMessageBox.warning(self,"警告","激活码错误！", QMessageBox.Yes)
            return
        # print(xor_u0,xor_u1,xor_u2,xor_u3)
        # print("Uid Check: ",uid_chk)    
        if (uid_chk==uid):
            Key = eval("".join(['0x',sliced_k[valid_pos[0]] ]))
            T1 = eval("".join(['0x',sliced_k[valid_pos[1]] ]))
            T2 = eval("".join(['0x',sliced_k[valid_pos[2]] ]))
            T3 = eval("".join(['0x',sliced_k[valid_pos[3]] ]))
            permitted_span = eval("".join(["0x",hex(T1^Key)[-1],hex(T2^Key)[-1],hex(T3^Key)[-1]]) )
            print("Activation OK! Permitted_span: ",permitted_span)
            self.ui.uid_str.setText("".join(uid))
            self.ui.permitted_span.setText(str(permitted_span))
        else:
            permitted_span = 0
            print("Activation Failed! Permitted_span: ",permitted_span)
      
 
#供调试时使用，改完logic不必切换到main.py后再运行程序 10.1.9.172
if __name__ == "__main__":
    app = QApplication(sys.argv)
    demo = Window()
    demo.setWindowIcon(QIcon("./imgs/icon_64x64.ico"))
    demo.show()
    sys.exit(app.exec_())

