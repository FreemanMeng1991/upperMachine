from uuid import uuid4
from random import randint

############### Request Code Generate ################
cnt      = 0
pos_char_idx = [0,0,0,0,0,0,0,0]
char_set = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
insert_at = ["X","X","X","X","X","X","X","X"]
request_code = []
valid_pos = []
pos_char = [] 
uid      = [char_set[randint(0,35)],char_set[randint(0,35)],char_set[randint(0,35)],char_set[randint(0,35)]]



while(cnt<8):
    index = randint(0,35)
    if (index%12) not in insert_at:
        pos_char_idx[cnt] = index
        insert_at[cnt] = index%12
        cnt = cnt + 1

for i in range(0,12):
    if not (i in insert_at):
        valid_pos.append(i)

for i in pos_char_idx:
    pos_char.append(char_set[i])
# pos_char = [char_set[pos_char_idx[0]],char_set[pos_char_idx[1]],char_set[pos_char_idx[2]],char_set[pos_char_idx[3]]]
request_code = "-".join(["".join(uid),"".join(pos_char[:4]),"".join(pos_char[4:])])
insert_at_bak = insert_at
print("############### Request Code Generate ################")
print("Uid: ",uid)
print("Select from: ", pos_char_idx)
print("Pos String: ",pos_char)
print("Insert at:",insert_at)
print("Request_code: ",request_code) 



############### Registration Code Generate ################

print("\n############### Registration Code Generate ################")
print("Get: ", request_code)
timespan = 743
reg_code = ['?','?','?','?','?','?','?','?','?','?','?','?']
pos_char_idx  = []
insert_at = []
xor_str  = []
pos_char = [request_code[5],request_code[6],request_code[7],request_code[8],request_code[10],request_code[11],request_code[12],request_code[13]]
uid      = list(request_code[:4])
uid_idx    = [char_set.index(uid[0]),char_set.index(uid[1]),char_set.index(uid[2]),char_set.index(uid[3])]
for i in range(0,8):
    pos_char_idx.append(char_set.index(pos_char[i]))
    insert_at.append(pos_char_idx[i]%12)
print("Uid: ",uid, "select from", uid_idx)
print("Pos String: ",pos_char, "select from",pos_char_idx)
print("Insert at: ", insert_at)

for u_idx, p_idx in zip(uid_idx, pos_char_idx):
    print(u_idx,p_idx,str(hex(u_idx^p_idx)[2:]).upper().zfill(2))
    xor_str.append(str(hex(u_idx^p_idx)[2:]).upper().zfill(2))

for i in range(0,8):
    reg_code[insert_at[i]] = xor_str[i//2][i%2]

reg_code[valid_pos[0]] = randint(0,15)

# print("XOR-ed Pos",p,"XOR-ed Val",reg_code[p],insert_at[i],char_set.index(uid[i]),reg_code[p]^char_set.index(uid[i]))
X  = randint(0,15)
T1 = timespan//256
T2 = (timespan - T1*256)//16
T3 = timespan - 256*T1 - 16*T2
reg_code[valid_pos[0]] = str(hex(X)).upper()[-1]
reg_code[valid_pos[1]] = str(hex(T1^X)).upper()[-1]
reg_code[valid_pos[2]] = str(hex(T2^X)).upper()[-1]
reg_code[valid_pos[3]] = str(hex(T3^X)).upper()[-1]

KEY_str = "-".join(["".join(reg_code[:4]),"".join(reg_code[4:8]),"".join(reg_code[8:])])

print("Valid Pos",valid_pos)
print(reg_code)
# print("".join(reg_code[8:]))
print("Registration Code: ",KEY_str)


print("\n############### Activation ################")
print("Get KEY_str: ", KEY_str)
print("Extract at: ",insert_at)

segments = KEY_str.split("-")
sliced_k = []
for s in segments:
    sliced_k.append(s[0])
    sliced_k.append(s[1])
    sliced_k.append(s[2])
    sliced_k.append(s[3])
print(sliced_k)
xor_u0 = eval("".join(['0x',sliced_k[insert_at[0]], sliced_k[insert_at[1]] ]))
xor_u1 = eval("".join(['0x',sliced_k[insert_at[2]], sliced_k[insert_at[3]] ]))
xor_u2 = eval("".join(['0x',sliced_k[insert_at[4]], sliced_k[insert_at[5]] ]))
xor_u3 = eval("".join(['0x',sliced_k[insert_at[6]], sliced_k[insert_at[7]] ]))
print(xor_u0,xor_u1,xor_u2,xor_u3)
print(char_set[xor_u0^pos_char_idx[0]],char_set[xor_u1^pos_char_idx[1]],char_set[xor_u2^pos_char_idx[2]],char_set[xor_u3^pos_char_idx[3]])    

Key = eval("".join(['0x',sliced_k[valid_pos[0]] ]))
T1 = eval("".join(['0x',sliced_k[valid_pos[1]] ]))
T2 = eval("".join(['0x',sliced_k[valid_pos[2]] ]))
T3 = eval("".join(['0x',sliced_k[valid_pos[3]] ]))
print(Key,T1,T2,T3)  
print(Key,eval("".join(["0x",hex(T1^Key)[-1],hex(T2^Key)[-1],hex(T3^Key)[-1]]) ) )
